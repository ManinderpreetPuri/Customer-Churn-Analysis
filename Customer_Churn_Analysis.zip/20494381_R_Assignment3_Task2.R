  #installing libraries
  library(dplyr)
  
  #Reading file
  df <- read.csv('telco_churn.csv')
  
  #----------------------------------------------------------------------------------------------------------------
  #Filtering churned as yes
  df_churn <- filter(df, Churn == "Yes")
  
  #Overall Churn rate
  Overall_churn_rate <- toString(round(nrow(df_churn)/nrow(df), 2))
  sprintf("Overall Churn rate is: %s", Overall_churn_rate)
  #----------------------------------------------------------------------------------------------------------------
  
  #Group Churn Rate
  
  #----------------------------------------------------------------------------------------------------------------
  
  #Group churn rate for variable "Gender"
  #--------------------Male--------------------#
  
  df_Gender_Male <- filter(df, Gender == "Male")
  
  df_Gender_Male_Churn <- filter(df_Gender_Male, Churn == "Yes")
  
  Group_Churn_Gender_Male <- toString(round(nrow(df_Gender_Male_Churn)/nrow(df_Gender_Male), 2))
  
  sprintf("Group Churn rate for variable Gender (Male) is: %s", Group_Churn_Gender_Male)
  
  #--------------------Female--------------------#
  
  df_Gender_Female <- filter(df, Gender == "Female")
  
  df_Gender_Female_Churn <- filter(df_Gender_Female, Churn == "Yes")
  
  Group_Churn_Gender_Female <- toString(round(nrow(df_Gender_Female_Churn)/nrow(df_Gender_Female), 2))
  
  sprintf("Group Churn rate for variable Gender (Female) is: %s", Group_Churn_Gender_Female)
  
  
  
  #Group churn rate for variable "SeniorCitizen"
  #--------------------Yes--------------------#
  
  df_SeniorCitizen_Yes <- filter(df, SeniorCitizen == "Yes")
  
  df_SeniorCitizen_Yes_Churn <- filter(df_SeniorCitizen_Yes, Churn == "Yes")
  
  Group_Churn_SeniorCitizen_Yes <- toString(round(nrow(df_SeniorCitizen_Yes_Churn)/nrow(df_SeniorCitizen_Yes), 2))
  
  sprintf("Group Churn rate for variable SeniorCitizen (Yes) is: %s", Group_Churn_SeniorCitizen_Yes)
  
  #--------------------No--------------------#
  
  df_SeniorCitizen_No <- filter(df, SeniorCitizen == "No")
  
  df_SeniorCitizen_No_Churn <- filter(df_SeniorCitizen_No, Churn == "Yes")
  
  Group_Churn_SeniorCitizen_No <- toString(round(nrow(df_SeniorCitizen_No_Churn)/nrow(df_SeniorCitizen_No), 2))
  
  sprintf("Group Churn rate for variable SeniorCitizen (No) is: %s", Group_Churn_SeniorCitizen_No)
  
  
  
  #Group churn rate for variable "Partner"
  #--------------------Yes--------------------#
  
  df_Partner_Yes <- filter(df, Partner == "Yes")
  
  df_Partner_Yes_Churn <- filter(df_Partner_Yes, Churn == "Yes")
  
  Group_Churn_Partner_Yes <- toString(round(nrow(df_Partner_Yes_Churn)/nrow(df_Partner_Yes), 2))
  
  sprintf("Group Churn rate for variable Partner (Yes) is: %s", Group_Churn_Partner_Yes)
  
  #--------------------No--------------------#
  
  df_Partner_No <- filter(df, Partner == "No")
  
  df_Partner_No_Churn <- filter(df_Partner_No, Churn == "Yes")
  
  Group_Churn_Partner_No <- toString(round(nrow(df_Partner_No_Churn)/nrow(df_Partner_No), 2))
  
  sprintf("Group Churn rate for variable Partner (No) is: %s", Group_Churn_Partner_No)
  
  
  
  #Group churn rate for variable "Dependents"
  #--------------------Yes--------------------#
  
  df_Dependents_Yes <- filter(df, Dependents == "Yes")
  
  df_Dependents_Yes_Churn <- filter(df_Dependents_Yes, Churn == "Yes")
  
  Group_Churn_Dependents_Yes <- toString(round(nrow(df_Dependents_Yes_Churn)/nrow(df_Dependents_Yes), 2))
  
  sprintf("Group Churn rate for variable Dependents (Yes) is: %s", Group_Churn_Dependents_Yes)
  
  #--------------------No--------------------#
  
  df_Dependents_No <- filter(df, Dependents == "No")
  
  df_Dependents_No_Churn <- filter(df_Dependents_No, Churn == "Yes")
  
  Group_Churn_Dependents_No <- toString(round(nrow(df_Dependents_No_Churn)/nrow(df_Dependents_No), 2))
  
  sprintf("Group Churn rate for variable Dependents (No) is: %s", Group_Churn_Dependents_No)
  
  
  
  #Group churn rate for variable "PhoneService"
  #--------------------Yes--------------------#
  
  df_PhoneService_Yes <- filter(df, PhoneService == "Yes")
  
  df_PhoneService_Yes_Churn <- filter(df_PhoneService_Yes, Churn == "Yes")
  
  Group_Churn_PhoneService_Yes <- toString(round(nrow(df_PhoneService_Yes_Churn)/nrow(df_PhoneService_Yes), 2))
  
  sprintf("Group Churn rate for variable PhoneService (Yes) is: %s", Group_Churn_PhoneService_Yes)
  
  #--------------------No--------------------#
  
  df_PhoneService_No <- filter(df, PhoneService == "No")
  
  df_PhoneService_No_Churn <- filter(df_PhoneService_No, Churn == "Yes")
  
  Group_Churn_PhoneService_No <- toString(round(nrow(df_PhoneService_No_Churn)/nrow(df_PhoneService_No), 2))
  
  sprintf("Group Churn rate for variable PhoneService (No) is: %s", Group_Churn_PhoneService_No)
  
  
  
  #Group churn rate for variable "PaperlessBilling"
  #--------------------Yes--------------------#
  
  df_PaperlessBilling_Yes <- filter(df, PaperlessBilling == "Yes")
  
  df_PaperlessBilling_Yes_Churn <- filter(df_PaperlessBilling_Yes, Churn == "Yes")
  
  Group_Churn_PaperlessBilling_Yes <- toString(round(nrow(df_PaperlessBilling_Yes_Churn)/nrow(df_PaperlessBilling_Yes), 2))
  
  sprintf("Group Churn rate for variable PaperlessBilling (Yes) is: %s", Group_Churn_PaperlessBilling_Yes)
  
  #--------------------No--------------------#
  
  df_PaperlessBilling_No <- filter(df, PaperlessBilling == "No")
  
  df_PaperlessBilling_No_Churn <- filter(df_PaperlessBilling_No, Churn == "Yes")
  
  Group_Churn_PaperlessBilling_No <- toString(round(nrow(df_PaperlessBilling_No_Churn)/nrow(df_PaperlessBilling_No), 2))
  
  sprintf("Group Churn rate for variable PaperlessBilling (No) is: %s", Group_Churn_PaperlessBilling_No)
  
  
  
  #Group churn rate for variable "MultipleLines"
  #--------------------Yes--------------------#
  
  df_MultipleLines_Yes <- filter(df, MultipleLines == "Yes")
  
  df_MultipleLines_Yes_Churn <- filter(df_MultipleLines_Yes, Churn == "Yes")
  
  Group_Churn_MultipleLines_Yes <- toString(round(nrow(df_MultipleLines_Yes_Churn)/nrow(df_MultipleLines_Yes), 2))
  
  sprintf("Group Churn rate for variable MultipleLines (Yes) is: %s", Group_Churn_MultipleLines_Yes)
  
  #--------------------No--------------------#
  
  df_MultipleLines_No <- filter(df, MultipleLines == "No")
  
  df_MultipleLines_No_Churn <- filter(df_MultipleLines_No, Churn == "Yes")
  
  Group_Churn_MultipleLines_No <- toString(round(nrow(df_MultipleLines_No_Churn)/nrow(df_MultipleLines_No), 2))
  
  sprintf("Group Churn rate for variable MultipleLines (No) is: %s", Group_Churn_MultipleLines_No)
  
  #--------------------No phone service--------------------#
  
  df_MultipleLines_No_phone_service <- filter(df, MultipleLines == "No phone service")
  
  df_MultipleLines_No_phone_service_Churn <- filter(df_MultipleLines_No_phone_service, Churn == "Yes")
  
  Group_Churn_MultipleLines_No_phone_service <- toString(round(nrow(df_MultipleLines_No_phone_service_Churn)/nrow(df_MultipleLines_No_phone_service), 2))
  
  sprintf("Group Churn rate for variable MultipleLines (No phone service) is: %s", Group_Churn_MultipleLines_No_phone_service)
  
  
  
  #Group churn rate for variable "InternetService"
  #--------------------DSL--------------------#
  
  df_InternetService_DSL <- filter(df, InternetService == "DSL")
  
  df_InternetService_DSL_Churn <- filter(df_InternetService_DSL, Churn == "Yes")
  
  Group_Churn_InternetService_DSL <- toString(round(nrow(df_InternetService_DSL_Churn)/nrow(df_InternetService_DSL), 2))
  
  sprintf("Group Churn rate for variable InternetService (DSL) is: %s", Group_Churn_InternetService_DSL)
  
  #--------------------Fiber optic--------------------#
  
  df_InternetService_Fiber_optic <- filter(df, InternetService == "Fiber optic")
  
  df_InternetService_Fiber_optic_Churn <- filter(df_InternetService_Fiber_optic, Churn == "Yes")
  
  Group_Churn_InternetService_Fiber_optic <- toString(round(nrow(df_InternetService_Fiber_optic_Churn)/nrow(df_InternetService_Fiber_optic), 2))
  
  sprintf("Group Churn rate for variable InternetService (Fiber optic) is: %s", Group_Churn_InternetService_Fiber_optic)
  
  #--------------------No--------------------#
  
  df_InternetService_No <- filter(df, InternetService == "No")
  
  df_InternetService_No_Churn <- filter(df_InternetService_No, Churn == "Yes")
  
  Group_Churn_InternetService_No <- toString(round(nrow(df_InternetService_No_Churn)/nrow(df_InternetService_No), 2))
  
  sprintf("Group Churn rate for variable InternetService (No) is: %s", Group_Churn_InternetService_No)
  
  
  
  
  
  #Group churn rate for variable "PhoneService"
  #--------------------Yes--------------------#
  
  df_PhoneService_Yes <- filter(df, PhoneService == "Yes")
  
  df_PhoneService_Yes_Churn <- filter(df_PhoneService_Yes, Churn == "Yes")
  
  Group_Churn_PhoneService_Yes <- toString(round(nrow(df_PhoneService_Yes_Churn)/nrow(df_PhoneService_Yes), 2))
  
  sprintf("Group Churn rate for variable PhoneService (Yes) is: %s", Group_Churn_PhoneService_Yes)
  
  #--------------------No--------------------#
  
  df_PhoneService_No <- filter(df, PhoneService == "No")
  
  df_PhoneService_No_Churn <- filter(df_PhoneService_No, Churn == "Yes")
  
  Group_Churn_PhoneService_No <- toString(round(nrow(df_PhoneService_No_Churn)/nrow(df_PhoneService_No), 2))
  
  sprintf("Group Churn rate for variable PhoneService (No) is: %s", Group_Churn_PhoneService_No)
  
  
  
  #Group churn rate for variable "PaperlessBilling"
  #--------------------Yes--------------------#
  
  df_PaperlessBilling_Yes <- filter(df, PaperlessBilling == "Yes")
  
  df_PaperlessBilling_Yes_Churn <- filter(df_PaperlessBilling_Yes, Churn == "Yes")
  
  Group_Churn_PaperlessBilling_Yes <- toString(round(nrow(df_PaperlessBilling_Yes_Churn)/nrow(df_PaperlessBilling_Yes), 2))
  
  sprintf("Group Churn rate for variable PaperlessBilling (Yes) is: %s", Group_Churn_PaperlessBilling_Yes)
  
  #--------------------No--------------------#
  
  df_PaperlessBilling_No <- filter(df, PaperlessBilling == "No")
  
  df_PaperlessBilling_No_Churn <- filter(df_PaperlessBilling_No, Churn == "Yes")
  
  Group_Churn_PaperlessBilling_No <- toString(round(nrow(df_PaperlessBilling_No_Churn)/nrow(df_PaperlessBilling_No), 2))
  
  sprintf("Group Churn rate for variable PaperlessBilling (No) is: %s", Group_Churn_PaperlessBilling_No)
  
  
  
  #Group churn rate for variable "TechSupport"
  #--------------------Yes--------------------#
  
  df_TechSupport_Yes <- filter(df, TechSupport == "Yes")
  
  df_TechSupport_Yes_Churn <- filter(df_TechSupport_Yes, Churn == "Yes")
  
  Group_Churn_TechSupport_Yes <- toString(round(nrow(df_TechSupport_Yes_Churn)/nrow(df_TechSupport_Yes), 2))
  
  sprintf("Group Churn rate for variable TechSupport (Yes) is: %s", Group_Churn_TechSupport_Yes)
  
  #--------------------No--------------------#
  
  df_TechSupport_No <- filter(df, TechSupport == "No")
  
  df_TechSupport_No_Churn <- filter(df_TechSupport_No, Churn == "Yes")
  
  Group_Churn_TechSupport_No <- toString(round(nrow(df_TechSupport_No_Churn)/nrow(df_TechSupport_No), 2))
  
  sprintf("Group Churn rate for variable TechSupport (No) is: %s", Group_Churn_TechSupport_No)
  
  #--------------------No internet service--------------------#
  
  df_TechSupport_No_internet_service <- filter(df, TechSupport == "No internet service")
  
  df_TechSupport_No_internet_service_Churn <- filter(df_TechSupport_No_internet_service, Churn == "Yes")
  
  Group_Churn_TechSupport_No_internet_service <- toString(round(nrow(df_TechSupport_No_internet_service_Churn)/nrow(df_TechSupport_No_internet_service), 2))
  
  sprintf("Group Churn rate for variable TechSupport (No internet service) is: %s", Group_Churn_TechSupport_No_internet_service)
  
  
  
  #Group churn rate for variable "StreamingTV"
  #--------------------Yes--------------------#
  
  df_StreamingTV_Yes <- filter(df, StreamingTV == "Yes")
  
  df_StreamingTV_Yes_Churn <- filter(df_StreamingTV_Yes, Churn == "Yes")
  
  Group_Churn_StreamingTV_Yes <- toString(round(nrow(df_StreamingTV_Yes_Churn)/nrow(df_StreamingTV_Yes), 2))
  
  sprintf("Group Churn rate for variable StreamingTV (Yes) is: %s", Group_Churn_StreamingTV_Yes)
  
  #--------------------No--------------------#
  
  df_StreamingTV_No <- filter(df, StreamingTV == "No")
  
  df_StreamingTV_No_Churn <- filter(df_StreamingTV_No, Churn == "Yes")
  
  Group_Churn_StreamingTV_No <- toString(round(nrow(df_StreamingTV_No_Churn)/nrow(df_StreamingTV_No), 2))
  
  sprintf("Group Churn rate for variable StreamingTV (No) is: %s", Group_Churn_StreamingTV_No)
  
  #--------------------No internet service--------------------#
  
  df_StreamingTV_No_internet_service <- filter(df, StreamingTV == "No internet service")
  
  df_StreamingTV_No_internet_service_Churn <- filter(df_StreamingTV_No_internet_service, Churn == "Yes")
  
  Group_Churn_StreamingTV_No_internet_service <- toString(round(nrow(df_StreamingTV_No_internet_service_Churn)/nrow(df_StreamingTV_No_internet_service), 2))
  
  sprintf("Group Churn rate for variable StreamingTV (No internet service) is: %s", Group_Churn_StreamingTV_No_internet_service)
  
  
  #Group churn rate for variable "StreamingMovies"
  #--------------------Yes--------------------#
  
  df_StreamingMovies_Yes <- filter(df, StreamingMovies == "Yes")
  
  df_StreamingMovies_Yes_Churn <- filter(df_StreamingMovies_Yes, Churn == "Yes")
  
  Group_Churn_StreamingMovies_Yes <- toString(round(nrow(df_StreamingMovies_Yes_Churn)/nrow(df_StreamingMovies_Yes), 2))
  
  sprintf("Group Churn rate for variable StreamingMovies (Yes) is: %s", Group_Churn_StreamingMovies_Yes)
  
  #--------------------No--------------------#
  
  df_StreamingMovies_No <- filter(df, StreamingMovies == "No")
  
  df_StreamingMovies_No_Churn <- filter(df_StreamingMovies_No, Churn == "Yes")
  
  Group_Churn_StreamingMovies_No <- toString(round(nrow(df_StreamingMovies_No_Churn)/nrow(df_StreamingMovies_No), 2))
  
  sprintf("Group Churn rate for variable StreamingMovies (No) is: %s", Group_Churn_StreamingMovies_No)
  
  #--------------------No internet service--------------------#
  
  df_StreamingMovies_No_internet_service <- filter(df, StreamingMovies == "No internet service")
  
  df_StreamingMovies_No_internet_service_Churn <- filter(df_StreamingMovies_No_internet_service, Churn == "Yes")
  
  Group_Churn_StreamingMovies_No_internet_service <- toString(round(nrow(df_StreamingMovies_No_internet_service_Churn)/nrow(df_StreamingMovies_No_internet_service), 2))
  
  sprintf("Group Churn rate for variable StreamingMovies (No internet service) is: %s", Group_Churn_StreamingMovies_No_internet_service)
  
  
  
  #Group churn rate for variable "Contract"
  #--------------------Month-to-month--------------------#
  
  df_Contract_Month_to_month <- filter(df, Contract == "Month-to-month")
  
  df_Contract_Month_to_month_Churn <- filter(df_Contract_Month_to_month, Churn == "Yes")
  
  Group_Churn_Contract_Month_to_month <- toString(round(nrow(df_Contract_Month_to_month_Churn)/nrow(df_Contract_Month_to_month), 2))
  
  sprintf("Group Churn rate for variable Contract (Month-to-month) is: %s", Group_Churn_Contract_Month_to_month)
  
  #--------------------Two year--------------------#
  
  df_Contract_Two_year <- filter(df, Contract == "Two year")
  
  df_Contract_Two_year_Churn <- filter(df_Contract_Two_year, Churn == "Yes")
  
  Group_Churn_Contract_Two_year <- toString(round(nrow(df_Contract_Two_year_Churn)/nrow(df_Contract_Two_year), 2))
  
  sprintf("Group Churn rate for variable Contract (Two_year) is: %s", Group_Churn_Contract_Two_year)
  
  #--------------------One year--------------------#
  
  df_Contract_One_year <- filter(df, Contract == "One year")
  
  df_Contract_One_year_Churn <- filter(df_Contract_One_year, Churn == "Yes")
  
  Group_Churn_Contract_One_year <- toString(round(nrow(df_Contract_One_year_Churn)/nrow(df_Contract_One_year), 2))
  
  sprintf("Group Churn rate for variable Contract (One year) is: %s", Group_Churn_Contract_One_year)
  
  
  
  
  #Group churn rate for variable "PaymentMethod"
  #--------------------Electronic check--------------------#
  
  df_PaymentMethod_Electronic_check <- filter(df, PaymentMethod == "Electronic check")
  
  df_PaymentMethod_Electronic_check_Churn <- filter(df_PaymentMethod_Electronic_check, Churn == "Yes")
  
  Group_Churn_PaymentMethod_Electronic_check <- toString(round(nrow(df_PaymentMethod_Electronic_check_Churn)/nrow(df_PaymentMethod_Electronic_check), 2))
  
  sprintf("Group Churn rate for variable PaymentMethod (Electronic check) is: %s", Group_Churn_PaymentMethod_Electronic_check)
  
  #--------------------Mailed check--------------------#
  
  df_PaymentMethod_Mailed_check <- filter(df, PaymentMethod == "Mailed check")
  
  df_PaymentMethod_Mailed_check_Churn <- filter(df_PaymentMethod_Mailed_check, Churn == "Yes")
  
  Group_Churn_PaymentMethod_Mailed_check <- toString(round(nrow(df_PaymentMethod_Mailed_check_Churn)/nrow(df_PaymentMethod_Mailed_check), 2))
  
  sprintf("Group Churn rate for variable PaymentMethod (Mailed check) is: %s", Group_Churn_PaymentMethod_Mailed_check)
  
  #--------------------One year--------------------#
  
  df_PaymentMethod_Bank_transfer <- filter(df, PaymentMethod == "Bank transfer (automatic)")
  
  df_PaymentMethod_Bank_transfer_Churn <- filter(df_PaymentMethod_Bank_transfer, Churn == "Yes")
  
  Group_Churn_PaymentMethod_Bank_transfer <- toString(round(nrow(df_PaymentMethod_Bank_transfer_Churn)/nrow(df_PaymentMethod_Bank_transfer), 2))
  
  sprintf("Group Churn rate for variable PaymentMethod (Bank transfer (automatic)) is: %s", Group_Churn_PaymentMethod_Bank_transfer)
  
  #--------------------Credit card (automatic)--------------------#
  
  df_PaymentMethod_Credit_card <- filter(df, PaymentMethod == "Credit card (automatic)")
  
  df_PaymentMethod_Credit_card_Churn <- filter(df_PaymentMethod_Credit_card, Churn == "Yes")
  
  Group_Churn_PaymentMethod_Credit_card <- toString(round(nrow(df_PaymentMethod_Credit_card_Churn)/nrow(df_PaymentMethod_Credit_card), 2))
  
  sprintf("Group Churn rate for variable PaymentMethod (Credit card (automatic)) is: %s", Group_Churn_PaymentMethod_Credit_card)
  